import React from "react";

// SyncNotifications DESATIVADO para prevenir notificações duplicadas
// Conforme solicitado por Gonçalo em Janeiro 2025
export function SyncNotifications() {
  // Componente completamente desativado - retorna null
  return null;
}
