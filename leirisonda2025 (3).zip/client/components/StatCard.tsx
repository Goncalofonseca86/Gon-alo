// This component is no longer used - dashboard uses inline stat cards with Leirisonda styling
export function StatCard() {
  return null;
}
