import React from "react";

// SyncNotification COMPLETAMENTE DESATIVADO para interface limpa
// Sincronização continua automática em background via useFirebaseSync
export function SyncNotification() {
  // Componente completamente desativado - retorna null
  return null;
}
